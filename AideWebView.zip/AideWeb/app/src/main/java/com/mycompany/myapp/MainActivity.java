package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.webkit.*;

public class MainActivity extends Activity 
{
	WebView w ;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		w = findViewById(R.id.w);
		w.getSettings().setJavaScriptEnabled(true);
	
		w.getSettings().setSupportZoom(true);
		w.setWebViewClient(new WebViewClient());
		w.loadUrl("https://www.google.com");
   
		}
}
